# curso-bootstrap-4-layout-01

Esse repositório contém o primeiro layout desenvolvido em nosso curso "Bootstrap 4 - Curso Completo"

É necessário executar o comando "npm install" no Terminal antes de testar o projeto
