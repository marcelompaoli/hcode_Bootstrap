# curso-bootstrap-4-layout-whatsapp

Este repositório contém o layout do WhatsApp desenvolvido em nosso treinamento "Bootstrap 4 - Curso Completo"
